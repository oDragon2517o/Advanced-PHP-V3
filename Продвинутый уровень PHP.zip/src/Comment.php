<?php

class Comment
{
    private $id;
    private $id_autor;
    private $header;
    private $id_article;
    private $text;
}

<?php

class User
{
    private $id;
    private $name;
    private $family;
}

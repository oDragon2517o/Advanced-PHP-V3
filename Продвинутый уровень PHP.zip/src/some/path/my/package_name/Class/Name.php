<?php

// namespace src\some\path\my\package_name\Class;

class Name
{
    public function __construct()
    {
        echo 'Loader Name' . PHP_EOL;
    }
}

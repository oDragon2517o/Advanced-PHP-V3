<?php

namespace src\some\path\Doctrine\Common;

// namespace namespace\package\Class;


class Name
{
    public $a = 239023;

    public function __construct($a = 112212)
    {

        echo 'Loader Name' . PHP_EOL;
        // echo $a;
    }
}

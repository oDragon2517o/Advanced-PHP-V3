<?php

namespace src\some\path\Doctrine\Common;

// namespace Doctrine\Common;

class ClassLoader
{
    public function __construct()
    {
        echo 'Loader ClassLoader' . PHP_EOL;
    }
}

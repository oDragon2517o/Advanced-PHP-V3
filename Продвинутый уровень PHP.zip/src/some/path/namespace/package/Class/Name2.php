<?php

namespace src\some\path\namespace\package\Class;

// namespace namespace\package\Class;


class Name2
{
    public $a = 239023;

    public function __construct($a = 'wwwwwww')
    {

        echo 'Loader Name2' . PHP_EOL;
        // echo $a;
    }
}

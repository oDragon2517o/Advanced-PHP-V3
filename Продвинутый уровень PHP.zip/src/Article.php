<?php

class Article
{
    private $id;
    private $id_autor;
    private $header;
    private $text;
}
